# Third-party notices

KeyWave Tables (Mac) carries these parts by other authors. Their licence texts are in the folder `Third-party licences`. The app itself is under the MIT License, see `LICENSE`.

| Name | Version | Licence |
|---|---|---|
| Python | 3.12.10 | PSF-2.0 (Python Software Foundation License); the software incorporated in Python under its own licences, see `Incorporated software.txt` next to it |
| OpenSSL | 3.0.16 | Apache-2.0 (libssl and libcrypto) |
| bottle | 0.13.4 | MIT |
| proxy_tools | 0.1.0 | MIT |
| pyinstaller | 6.22.3 | GPL-2.0-or-later with the bootloader exception; run-time hooks Apache-2.0 |
| pyobjc-core | 12.2.2 | MIT |
| pyobjc-framework-Cocoa | 12.2.2 | MIT |
| pyobjc-framework-Quartz | 12.2.2 | MIT |
| pyobjc-framework-Security | 12.2.2 | MIT |
| pyobjc-framework-UniformTypeIdentifiers | 12.2.2 | MIT |
| pyobjc-framework-WebKit | 12.2.2 | MIT |
| pywebview | 6.2.1 | BSD 3-Clause License |
| typing_extensions | 4.16.0 | PSF-2.0 |
