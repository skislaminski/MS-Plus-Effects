@echo off
rem Same program, but with a console window that shows error messages.
rem Use this if nothing happens when you start the normal one.
"%~dp0python\python.exe" "%~dp0app\keywave_gui.py"
echo.
pause
