KeyWave Tables - Windows (x64)
==============================

Start:  double-click "KeyWave Tables.bat".
        Nothing needs to be installed; keep this folder together.

The window opens in Microsoft Edge (as an app window without address bar).
Without Edge it opens as a tab in your standard browser. Close the window
when you are done: the program ends by itself a few seconds later.
If Windows shows "Windows protected your PC" on the first start, choose
"More info" and then "Run anyway" - the files are not signed.

If nothing happens: start "KeyWave Tables (show errors).bat" and read what
it prints.

How to use it: see README.md in this folder.

STATUS: this Windows package was assembled on a Mac and has NEVER been run
on Windows. The same program code was tested on macOS 15.

Unofficial, not made or supported by Zoom - use at your own risk.

License: MIT, see LICENSE in this folder. Python's licence, and the licences
of the software Python carries (OpenSSL, bzip2, libffi and others): python\LICENSE.txt.

Contents: python\  Python 3.12.10 for Windows from python.org (embeddable
                   package, sha256 4acbed6dd1c744b0376e3b1cf57ce906f9dc9e95e68824584c8099a63025a3c3)
          app\     the program, the KeyWave effect it starts from (base\)
                   and example wavetables (examples\)
