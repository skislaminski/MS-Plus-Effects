@echo off
rem Starts KeyWave Tables. Its window opens in Microsoft Edge (app mode);
rem without Edge it opens as a tab in your standard browser.
start "" "%~dp0python\pythonw.exe" "%~dp0app\keywave_gui.py"
