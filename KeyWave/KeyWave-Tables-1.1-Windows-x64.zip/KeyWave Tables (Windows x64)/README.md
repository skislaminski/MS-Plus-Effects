# KeyWave Tables

Puts a wavetable of your own into the KeyWave effect (`KEYWAVE.ZD2`) for the Zoom MS-60B+, without building the effect again. No compiler, and the program never talks to the pedal: it writes `KEYWAVE.ZD2` and `KEYWAVE.ZIC`, which you install with [stomphacks](https://github.com/thammer/stomphacks), like every effect of [MS Plus Effects](https://github.com/skislaminski/MS-Plus-Effects).

> **Unofficial.** Not made, affiliated with or supported by Zoom. Read stomphacks' [SAFETY.md](https://github.com/thammer/stomphacks/blob/main/SAFETY.md) and back up your pedal before you install anything. A faulty effect in a saved patch, or a transfer that is interrupted, can leave a pedal unable to start. Use it at your own risk.

## Requirements

- a Mac with macOS 12 or newer, Apple silicon or Intel (one app for both), or a PC with Windows 10 or 11 (x64)
- a Zoom MS-60B+ (firmware 1.20) and [stomphacks](https://github.com/thammer/stomphacks), to put the result on the pedal

Tested only on macOS 15 on Apple silicon; the Intel part of the Mac app only under Rosetta. It has never been run on Windows, on macOS 12 to 14 or on a real Intel Mac.

## Starting it

**Mac:** unzip `KeyWave-Tables-1.1-Mac.zip` and open `KeyWave Tables.app`. The first start takes about 15 seconds, because macOS checks the app once. The app is not signed by Apple, so macOS stops it the first time: on macOS 15 or newer, open *System Settings → Privacy & Security* and click *Open Anyway*; on older versions, right-click the app and choose *Open*. macOS may also ask once whether the app may use your Documents folder: allow it, that is where the effects go. If you clicked *Don't Allow*, *Make* says that the app may not write there: turn it on under *System Settings → Privacy & Security → Files and Folders → KeyWave Tables → Documents Folder*.

**Windows:** the Windows version is a portable folder, nothing is installed. Unzip `KeyWave-Tables-1.1-Windows-x64.zip`, keep the folder together and double-click `KeyWave Tables.bat`. The window opens in Microsoft Edge as an app window (no address bar); without Edge it opens as a tab in your standard browser. Close it when you are done: the program ends by itself a few seconds later. If Windows shows "Windows protected your PC" on the first start, choose *More info*, then *Run anyway* (the files are not signed). If nothing happens at all, start `KeyWave Tables (show errors).bat` and read what it prints. If *Make* says that the app may not write to Documents, Windows' *Controlled folder access* is blocking it: allow `python\pythonw.exe` from the KeyWave Tables folder under *Windows Security → Virus & threat protection → Ransomware protection*.

## Using it

1. **Load a wavetable.** Drop a WAV file onto the window, click the drop area to choose one, or pick one of the examples. It reads WAV files in 16, 24 or 32 bit or 32 bit float, mono or stereo (stereo is mixed to mono). Tested with files made to these layouts: wavetables laid out like Serum and Vital exports (with a `clm ` chunk), WaveEdit banks (64 frames of 256) and AKWF single cycles (600 samples). Files exported from those programs themselves have not been tried.
2. **Check how it was read.** The line at the bottom of step 1 says how many frames the file has, how long they are and which 8 of them go into the effect. If the frame length is wrong, choose it under *Frame length*. *Normalize* sets the level: the whole table to full level (default), each frame to full level, or off (the level as in the file).
3. **Listen.** Move the *Wave* slider through the 8 frames and play the keys E1 to C4 with the mouse, or with A S D F G H J K on your computer keyboard. Click a small picture to jump to that frame.
4. **Make the effect.** Give the table a name (up to 24 letters, digits, spaces and `_ . + -`; dots and spaces at the start or end are dropped) and click **Make KEYWAVE.ZD2**. The box below says where the files went; *Show in Finder* (Mac) or *Show in Explorer* (Windows) opens that folder.
5. **Put it on the pedal** with stomphacks, as described below.

Drop a finished `KEYWAVE.ZD2` onto the window to see which table is in it.

## Where the files go

Into `Documents/KeyWave Tables/<name>/` (the folder is made when you write the first effect):

- `KEYWAVE.ZD2`: the KeyWave effect with your table
- `KEYWAVE.ZIC`: its picture on the pedal (unchanged)
- `TABLE.json`: where the table came from, how it was cut into frames, and checksums of the base effect and of the new file

If that folder already holds a different `KEYWAVE.ZD2`, the new one goes into `<name> 2`, `<name> 3` and so on.

## Installing it with stomphacks

The new file carries the same header, file name and ID as the KeyWave of MS Plus Effects, so the old one has to go first. From the stomphacks folder, one command at a time, checking each result (on Windows use `.venv\Scripts\python.exe` in place of `.venv/bin/python3`):

1. `.venv/bin/python3 tools-pedal/safe_connect.py session/` (confirms AUTO SAVE is off), then `.venv/bin/python3 tools-pedal/backup_pedal.py backup/`.
2. Take KeyWave out of all patches.
3. `.venv/bin/python3 tools-pedal/pedal_diy.py uninstall <folder above>/KEYWAVE.ZD2` removes the KeyWave that is on the pedal (same ID and file name).
4. `.venv/bin/python3 tools-pedal/pedal_diy.py install <folder above>/KEYWAVE.ZD2` (the `KEYWAVE.ZIC` next to it goes along), then `.venv/bin/python3 tools-pedal/readback.py KEYWAVE.ZD2 session/KEYWAVE-new.ZD2` and compare it with the file.
5. Try it in an unsaved patch first, with the amp turned down.

The knobs and the ID stay the same; only the table is new, so saved knob settings still work.

## What it does

- **Frames:** KeyWave's table always has 8 frames; that number is fixed in the effect. From a file with more frames, 8 are taken, spread evenly from the first to the last (a place between two frames gets a blend of both); a file with fewer is stretched, the frames in between are blends of their neighbours (a single cycle sounds the same at every position of Wave). This is the same code that is used when the effect is built (`wt_import.py`).
- **Frame length:** a `clm ` chunk in the file (Serum, Vital) decides it, if it names 8 to 4096 samples. A short file that fits no usual length is one cycle (AKWF: 600 samples). Otherwise it is the largest of 256 to 2048 that divides the file. If the first frame that is not silent then has almost nothing below what would be its fundamental, and most of its sound on the harmonics of a shorter frame, the frames are shorter: that is how WaveEdit files (64 × 256) are recognised. You can also choose the length by hand (8 to 4096 samples).
- **Putting the table in:** in the effect's code the wave comes right after its other tables (1796 bytes that do not depend on the wave). The program looks for those bytes in the base effect, requires them exactly once with 9984 bytes of room behind them, writes the new wave over the old one, puts the table's name into the effect's description and sets the file's checksum again. Nothing else changes.
- **Checked:** with the built-in table the result is the base file, byte for byte. With the organ example it is byte for byte the same file as a real rebuild of KeyWave with that table. The files are written under a temporary name first, so an interrupted write never leaves a cut-off `KEYWAVE.ZD2`.

## Limits

- The preview in the window plays the 8 frames with crossfades, as the effect does. Envelope, Sub, LFO and Glide only happen in the effect.
- The base is the KeyWave that came with the app; its SHA-256 is in `TABLE.json`. When KeyWave itself changes, you need a new version of this app.
- Tested only on macOS 15 on Apple silicon (the Intel part of the Mac app only under Rosetta). Never run on Windows, on macOS 12 to 14 or on a real Intel Mac; the Windows version was assembled on a Mac.

## License

MIT, see `LICENSE`. The `KEYWAVE.ZD2` the app starts from holds the effect scaffold that stomphacks by Thomas Hammer (Waveformer) generates, MIT as well; both are named in `LICENSE`. The app comes with Python and, on the Mac, with pywebview, PyObjC, OpenSSL and other parts; their licences are in the folder `Third-party licences` (Mac) or in `python\LICENSE.txt` (Windows).
